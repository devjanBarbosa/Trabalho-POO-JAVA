package Trabalho;

public class Menu {
	
	public String menuprincipal(){
		return "CRIADO BY : JAN LUIZ\n==================\n     MENU \n==================\n1 - Lancha\n2 - Iate\n3 - JetSki\n==================\nDigite uma opção: ";
	}
	public String menucarro1(String a, String b, String c, String d, String e) {
		return "Qual Lancha você deseja ver? \nMarca 1 : " + a +"\nMarca 2 : " + b + "\nMarca 3 : " + c + "\nMarca 4 : " + d + "\nMarca 5 : " + e + "\n==================\nDigite uma opção: ";
	}

}
